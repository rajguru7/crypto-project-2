# dummy.py
def hello_world():
    return "This project is to demo piptuf!"
